﻿namespace Hydrix.Schemas
{
    /// <summary>
    /// Represents a Sql Table that holds the data to be parsed from the DataSet result.
    /// </summary>
    public interface ISqlEntity
    { }
}