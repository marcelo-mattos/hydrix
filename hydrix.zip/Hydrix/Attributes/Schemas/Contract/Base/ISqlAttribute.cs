﻿namespace Hydrix.Attributes.Schemas.Contract.Base
{
    /// <summary>
    /// Define an Sql object of any kind.
    /// </summary>
    public interface ISqlAttribute
    { }
}